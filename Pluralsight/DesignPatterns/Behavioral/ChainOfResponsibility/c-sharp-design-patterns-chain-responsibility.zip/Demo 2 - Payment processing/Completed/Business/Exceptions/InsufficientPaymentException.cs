﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Payment_processing.Business.Exceptions
{
    public class InsufficientPaymentException : Exception
    {
    }
}
