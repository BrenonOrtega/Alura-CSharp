﻿namespace DesignPatternsInCSharp.Adapter.ThirdPartyApi
{
    public enum Gender
    {
        Male,
        Female,
        NotApplicable
    }
}
