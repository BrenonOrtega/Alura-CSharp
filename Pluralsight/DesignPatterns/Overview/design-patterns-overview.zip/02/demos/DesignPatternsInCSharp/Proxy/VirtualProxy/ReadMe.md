﻿# Virtual Proxy

- Stands in for expensive-to-create object
- Gets real object itself
- Used for UI placeholders
- Used for lazy loading
